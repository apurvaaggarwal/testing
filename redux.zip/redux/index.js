import { combineReducers } from 'redux';
import { toastReducer as toast } from 'react-native-redux-toast';
import app from "./modules/app";
import nav from "./modules/nav";
import user from "./modules/user";
import location from "./modules/location";
import ModalHandleReducer from './modules/modalClose';
import notifications from './modules/notifications';

export default function getRootReducer() {
    return combineReducers({
        toast,
        app,
        nav,
        user,
        location,
        notifications,
        ModalHandleReducer
    });
}
