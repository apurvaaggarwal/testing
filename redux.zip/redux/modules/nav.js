'use strict';
import { NavigationActions } from "react-navigation";
import { AppNavigator } from "../../config/navigator";
import { REHYDRATE } from "redux-persist/constants";
//import { REHYDRATE } from "redux-persist";
import { USER_TYPE, RESET_PASSWORD, GO_TO_LOGIN,
     SERVICES_AND_SCHEDULING, DASH_BOARD, REFERRAL_DATA_CUSTOMER,
     SCHEDULE_AND_PRODUCTS, CUSTOMER_DASH_BOARD, MOVE_TO_DASH_BOARD } from './user';


//Actions
const GOBACK            = "GOBACK";
const ResetNavigator    = "ResetNavigator";
const GOTO              = "GOTO";


// Action Creators
export const goBack = () => ({ type: GOBACK });
export const reset  = (data) => {
    return({ type: ResetNavigator, data })
};
export const goTo   = (data) => ({ type: GOTO, data });


const initialState = AppNavigator.router.getStateForAction(NavigationActions.reset({
    index: 0,
    actions: [
      NavigationActions.navigate({
        routeName: 'Loader',
      }),
    ],
}));

export default function reducer(state = initialState, action) {
  
  console.log('**** PAYLOAD ****',action.payload)
  
    let firstState = "SplashScreen";
    if(action.payload && action.payload.user && action.payload.user.userDetails && action.payload.user.userDetails.data && action.payload.user.userDetails.data.isScheduled && action.payload.user.userDetails.data.role == "Service Provider"){
        firstState = "Dashboard"
    } 
    else if(action.payload && action.payload.user && action.payload.user.userDetails && action.payload.user.userDetails.data && action.payload.user.userDetails.data.isScheduled && action.payload.user.userDetails.data.role == "Customer"){
        firstState = "CustomerDashboard"
    } 
    else if(action.payload && action.payload.user && action.payload.user.userDetails && action.payload.user.userDetails.data && action.payload.user.userDetails.data.role == "") {
        firstState = "ChooseUserType"
    }
    else if(action.payload && action.payload.user && action.payload.user.userDetails && action.payload.user.userDetails.data && action.payload.user.userDetails.data.isScheduled == false && action.payload.user.userDetails.data.role == "Service Provider") {      
        firstState = "ServicesAndProduct"
    }
    else if(action.payload && action.payload.user && action.payload.user.userDetails && action.payload.user.userDetails.data && action.payload.user.userDetails.data.isScheduled == false && action.payload.user.userDetails.data.role == "Customer") {
        firstState = "ScheduleAndProduct"
    }   
    else{
        firstState = "Login"
    }

    switch (action.type) {
    
        case ResetNavigator:
        
            return AppNavigator.router.getStateForAction(
                NavigationActions.reset({
                  index: 0,
                  actions: [NavigationActions.navigate({ routeName: "SplashScreen" })],
                }),
                state
            );
            case DASH_BOARD:
            
            return AppNavigator.router.getStateForAction(
                NavigationActions.reset({
                  index: 0,
                  actions: [NavigationActions.navigate({ routeName: "Dashboard" })],
                }),
                state
            );
            case CUSTOMER_DASH_BOARD:
            return AppNavigator.router.getStateForAction(
                NavigationActions.reset({
                  index: 0,
                  actions: [NavigationActions.navigate({ routeName: "CustomerDashboard" })],
                }),
                state
            );

        case SERVICES_AND_SCHEDULING:
        return AppNavigator.router.getStateForAction(
            NavigationActions.reset({
              index: 0,
              actions: [NavigationActions.navigate({ routeName: "ServicesAndProduct" })],
            }),
            state
        );
        case SCHEDULE_AND_PRODUCTS:
        return AppNavigator.router.getStateForAction(
            NavigationActions.reset({
              index: 0,
              actions: [NavigationActions.navigate({ routeName: "ScheduleAndProduct" })],
            }),
            state
        );

        case USER_TYPE:
        return AppNavigator.router.getStateForAction(
            NavigationActions.reset({
              index: 0,
              actions: [NavigationActions.navigate({ routeName: "ChooseUserType" })],
            }),
            state
        );
        // case MOVE_TO_DASH_BOARD:
            
        // return AppNavigator.router.getStateForAction(
        //     NavigationActions.reset({
        //       index: 0,
        //       actions: [NavigationActions.navigate({ routeName: "Schedules" })],
        //     }),
        //     state
        // );
       
        case RESET_PASSWORD:
        return AppNavigator.router.getStateForAction(
            NavigationActions.reset({
              index: 0,
              actions: [NavigationActions.navigate({ routeName: "ResetPassword" })],
            }),
            state
        );

        case REFERRAL_DATA_CUSTOMER:
        return AppNavigator.router.getStateForAction(
            NavigationActions.reset({
              index: 0,
              actions: [NavigationActions.navigate({ routeName: "ReferralSchedules" })],
            }),
            state
        );

        case GO_TO_LOGIN:
        return AppNavigator.router.getStateForAction(
            NavigationActions.reset({
              index: 0,
              actions: [NavigationActions.navigate({ routeName: "Login" })],
            }),
            state
        );

        case GOBACK:
            return AppNavigator.router.getStateForAction(
                NavigationActions.back(),
                state
            );


        case GOTO:
        return AppNavigator.router.getStateForAction(
            NavigationActions.navigate({
                routeName: action.data.route,
                params: action.data.params || {},
            }),
            state
        );
            

        case REHYDRATE:
            return AppNavigator.router.getStateForAction(
                NavigationActions.reset({
                  index: 0,
                  actions: [NavigationActions.navigate({ routeName: firstState })],
                }),
                state
            );

        default:
            return AppNavigator.router.getStateForAction(action, state);
    }
}