'use strict';

import { startLoading, stopLoading, showToast, hideToast } from './app';
import { ToastActionsCreators } from 'react-native-redux-toast';
import RestClient from '../../utilities/RestClient';
import { Alert } from 'react-native';
import Strings from '../../constants/Strings';

// Actions

export const REGISTER_NEW_USER = "REGISTER_NEW_USER";
export const USER_TYPE = "USER_TYPE";
export const RESET_PASSWORD = "RESET_PASSWORD";
export const GO_TO_LOGIN = "GO_TO_LOGIN";
export const APP_SERVICES = "APP_SERVICES"
export const SERVICES_AND_SCHEDULING = "SERVICES_AND_SCHEDULING";
export const DASH_BOARD = "DASH_BOARD";
export const REFERRAL_DATA = "REFERRAL_DATA";
export const USER_SERVICES = "USER_SERVICES";
export const PRODUCT_DATA = "PRODUCT_DATA";
export const CUSTOMER_LIST = "CUSTOMER_LIST";
export const CUSTOMER_DATA = "CUSTOMER_DATA";
export const OFF_DATE_ENTRY = "OFF_DATE_ENTRY";
export const SCHEDULE_STATUS = "SCHEDULE_STATUS";
export const GET_EARNING = "GET_EARNING";
export const GET_COUNT = "GET_COUNT";
export const LOG_OUT = "LOG_OUT";
export const PROFILE_DATA = "PROFILE_DATA";
export const MOVE_TO_DASH_BOARD = "MOVE_TO_DASH_BOARD";
export const GET_REPORTS = "GET_REPORTS";
export const PRODUCT_UNITS = "PRODUCT_UNITS";
export const NOTIFICATION_SETTINGS = "NOTIFICATION_SETTINGS";
export const PRODUCT_DATA1 = "PRODUCT_DATA1";
export const USER_SERVICES1 = "USER_SERVICES1";

export const SERVICE_PROVIDER_LIST = "SERVICE_PROVIDER_LIST";
export const SERVICE_PROVIDER_DATA = "SERVICE_PROVIDER_DATA";
export const REFERRAL_DATA_CUSTOMER = "REFERRAL_DATA_CUSTOMER";
export const SCHEDULE_AND_PRODUCTS = "SCHEDULE_AND_PRODUCTS";
export const CUSTOMER_DASH_BOARD = "CUSTOMER_DASH_BOARD";
export const DEVICE_TOKEN = "DEVICE_TOKEN";
export const COUNTRY_CODES = "COUNTRY_CODES";
export const COUNTRY_CODE = "COUNTRY_CODE";
export const NUMBER_EXISTENCE = "NUMBER_EXISTENCE";
export const SUCCESS_DONE = "SUCCESS_DONE";
export const NOTIFICATION_DATA = "NOTIFICATION_DATA";
export const NOTIFICATION_COUNT = "NOTIFICATION_COUNT"



// Action Creators
export const SIGNUP = (data) => ({ type: REGISTER_NEW_USER, data });
export const CHOOSEUSERTYPE = (data) => ({ type: USER_TYPE, data });
export const RESETPASSWORD = (data) => ({ type: RESET_PASSWORD, data });
export const LOGIN = (data) => ({ type: GO_TO_LOGIN, data });
export const DASHBOARD = (data) => ({ type: DASH_BOARD, data });
export const SERVICESANDSCHEDULING = (data) => ({ type: SERVICES_AND_SCHEDULING, data });
export const REFERRALDATA = (data) => ({ type: REFERRAL_DATA, data });
export const USERSERVICES = (data) => ({ type: USER_SERVICES, data });
export const PRODUCTDATA = (data) => ({ type: PRODUCT_DATA, data });
export const CUSTOMERLIST = (data) => ({ type: CUSTOMER_LIST, data })
export const CUSTOMERDATA = (data) => ({ type: CUSTOMER_DATA, data })
export const APPSERVICES = (data) => ({ type: APP_SERVICES, data })
export const OFFDATEENTRY = (data) => ({ type: OFF_DATE_ENTRY, data })
export const SCHEDULESTATUS = (data) => ({ type: SCHEDULE_STATUS, data })
export const GETEARNING = (data) => ({ type: GET_EARNING, data })
export const GETCOUNT = (data) => ({ type: GET_COUNT, data })
export const PROFILEDATA = (data) => ({ type: PROFILE_DATA, data })
export const LOGOUT = (data) => ({ type: LOG_OUT, data })
export const MOVETODASHBOARD = () => ({ type: MOVE_TO_DASH_BOARD })
export const GETREPORTS = (data) => ({ type: GET_REPORTS, data })
export const PRODUCTUNITS = (data) => ({ type: PRODUCT_UNITS, data })
export const COUNTRYCODES = (data) => ({ type: COUNTRY_CODES, data })
export const COUNTRYCODE = (data) => ({ type: COUNTRY_CODE, data })
export const NOTIFICATIONSETTINGS = (data) => ({ type: NOTIFICATION_SETTINGS, data })
export const PRODUCTDATA1 = (data) => ({ type: PRODUCT_DATA1, data });
export const USERSERVICES1 = (data) => ({ type: USER_SERVICES1, data });


export const SERVICEPROVIDERLIST = (data) => ({ type: SERVICE_PROVIDER_LIST, data })
export const SERVICEPROVIDERDATA = (data) => ({ type: SERVICE_PROVIDER_DATA, data })
export const REFERRALDATACUSTOMER = (data) => ({ type: REFERRAL_DATA_CUSTOMER, data })
export const SCHEDULEANDPRODUCTS = (data) => ({ type: SCHEDULE_AND_PRODUCTS, data })
export const CUSTOMERDASHBOARD = (data) => ({ type: CUSTOMER_DASH_BOARD, data })
export const SETDEVICETOKEN = (data) => ({ type: DEVICE_TOKEN, data });
export const NUMBEREXISTENCE = (data) => ({ type: NUMBER_EXISTENCE, data });

export const SUCCESS = (data) => ({ type: SUCCESS_DONE, data });
export const NOTIFICATIONDATA = (data) => ({ type: NOTIFICATION_DATA, data });
export const NOTIFICATIONCOUNT = (data) => ({ type: NOTIFICATION_COUNT, data });



//perform API's

/**
* Toast API.
*/
export const toast = (message) => {
	console.log(message)
	return dispatch => {
		try {
			console.log(message)
			dispatch(ToastActionsCreators.displayInfo(message));
		}
		catch (e) {
			console.log(e)
		}


	}
};
/**
* Signup API.
*/
export const signUp = (data) => {
	console.log(data)

	let requestObject = {
		phoneNumber: data.code + data.phone,
		password: data.password
	}

	return dispatch => {
		dispatch(startLoading());
		RestClient.post("users/createUser", requestObject).then((result) => {
			console.log(result, "****** signUp ********")
			if (result.statusCode === 200) {
				dispatch(COUNTRYCODE( data.code));
				dispatch(stopLoading());

				dispatch(SIGNUP(result));
				dispatch({ type: 'PHONEVERIFICATION_VISIBILITY', visibility: true })
		
			} 
			else if (result.statusCode === 400){
				dispatch(stopLoading());
				if(result.data.isVerified == false)
				{	dispatch(SIGNUP(result));
					dispatch({ type: 'PHONEVERIFICATION_VISIBILITY', visibility: true })}
			
			}
			else {
				dispatch(stopLoading());
				dispatch(ToastActionsCreators.displayInfo(result.message));
			}
		}).catch(error => {
			console.log("error=> ", error)
			dispatch(stopLoading());
		});
	}
};


/**
* Phone Verification API.
*/
export const phoneVerification = (data) => {
	console.log(data)

	let requestObject = {
		verificationCode: data.code
	}

	return dispatch => {
		dispatch(startLoading());
		RestClient.post("users/verifyOtp", requestObject, data.user.token).then((result) => {
			console.log(result, "****** phoneVerification ********")
			if (result.statusCode === 200) {
				dispatch(stopLoading());
				dispatch({ type: 'PHONEVERIFICATION_VISIBILITY', visibility: false })
				// dispatch(ToastActionsCreators.displayInfo(result.message));
				dispatch(CHOOSEUSERTYPE(result));
			}
			else {
				dispatch(stopLoading());
				Alert.alert(
					Strings.common.alert,
					result.message,
					[{text: 'OK', onPress: () => console.log('OK Pressed'), style: 'cancel'}],
					{ cancelable: false }
				  )
				  return true;
				// dispatch(ToastActionsCreators.displayInfo(result.message));
			}
		}).catch(error => {
			console.log("error=> ", error)
			dispatch(stopLoading());
		});
	}
};


/**
* Login API.
*/
export const login = (data) => {
	console.log(data)

	let requestObject = {
		phoneNumber: data.code + data.number,
		password: data.password
	}

	return dispatch => {
		dispatch(startLoading());

		RestClient.post("users/login", requestObject).then((result) => {
			console.log(result, '******* login *******')
			if (result.statusCode === 200) {
				dispatch(stopLoading())
				// dispatch(ToastActionsCreators.displayInfo(result.data.role));
				dispatch(COUNTRYCODE(data.code));
				if (result.data.role == "Service Provider" && result.data.isScheduled == true) {
					dispatch(DASHBOARD(result));
					dispatch(COUNTRYCODE(data.code));
				}
				else if (result.data.role == "Customer" && result.data.isScheduled == true) {
					dispatch(CUSTOMERDASHBOARD(result));
				}
				else if (result.data.role == "") {
					dispatch(CHOOSEUSERTYPE(result));
				}
				else if (result.data.isScheduled == false && result.data.role == "Service Provider") {
					dispatch(SERVICESANDSCHEDULING(result));
				}
				else if (result.data.isScheduled == false && result.data.role == "Customer") {
					dispatch(SCHEDULEANDPRODUCTS(result));
				}
				else if (result.data.isVerified == false) {
					dispatch(SIGNUP(result));
					dispatch({ type: 'PHONEVERIFICATION_VISIBILITY', visibility: true })
				}
			}
			else if(result.statusCode === 400) {
				dispatch(stopLoading());
				dispatch(ToastActionsCreators.displayInfo("Please fill valid credentials"));
			}
			else {
				dispatch(ToastActionsCreators.displayInfo(result.message));
				if (result.data.isVerified) {
					dispatch(stopLoading());
					// dispatch(ToastActionsCreators.displayInfo(result.message));
				}
			
				else {
					dispatch(stopLoading());
					

				}

			}
		}).catch(error => {
			console.log("error=> ", error)
			dispatch(stopLoading());
		});
	}
};


/**
* Forgot API.
*/
export const forgotPassword = (data) => {
	console.log(data)

	let requestObject = {
		phoneNumber:  data.code + data.number 
	}

	return dispatch => {
		dispatch(startLoading());
		RestClient.post("users/forgotPassword", requestObject).then((result) => {
			console.log(result, '****** forgotPassword ****')
			if (result.statusCode === 200) {
				dispatch(stopLoading());
				// dispatch(ToastActionsCreators.displayInfo(result.message));
				dispatch(RESETPASSWORD(result));
			}
			else {
				dispatch(stopLoading());
				dispatch(ToastActionsCreators.displayInfo(result.message));
			}
		}).catch(error => {
			console.log("error=> ", error)
			dispatch(stopLoading());
		});
	}
};


/**
* reset API.
*/
export const resetPassword = (data) => {
	console.log(data)

	let requestObject = {
		userId: data.user.userDetails.data.userId,
		verificationCode: data.code,
		password: data.password
	}

	return dispatch => {
		dispatch(startLoading());
		RestClient.post("users/resetPassword", requestObject).then((result) => {
			console.log(result, '****** resetPassword ****')
			if (result.statusCode === 200) {
				dispatch(stopLoading());
				// dispatch(ToastActionsCreators.displayInfo(result.message));
				dispatch(LOGIN(result));
			}
			else {
				dispatch(stopLoading());
				dispatch(ToastActionsCreators.displayInfo(result.message));
			}
		}).catch(error => {
			console.log("error=> ", error)
			dispatch(stopLoading());
		});
	}
};




export const getAllServices = () => {


	return dispatch => {
		dispatch(startLoading());
		RestClient.get("users/getAllServices").then((result) => {
			console.log(result, '****** getAllServices ****')
			if (result.statusCode === 200) {
			
				dispatch(stopLoading());
				// dispatch(ToastActionsCreators.displayInfo(result.message));
				dispatch(APPSERVICES(result));
			}
			else {
				dispatch(stopLoading());
				// dispatch(ToastActionsCreators.displayInfo(result.message));
			}
		}).catch(error => {
			console.log("error=> ", error)
			dispatch(stopLoading());
		});
	}
};


export const getCountryCodes = () => {


	return dispatch => {
		dispatch(startLoading());
		RestClient.get("users/getCountryCodes").then((result) => {
			console.log(result, '****** getCountryCodes ****')
			if (result.statusCode === 200) {
				dispatch(stopLoading());
				dispatch(COUNTRYCODES(result));
			}
			else {
				dispatch(stopLoading());
			}
		}).catch(error => {
			console.log("error=> ", error)
			dispatch(stopLoading());
		});
	}
};




export const getProductUnits = (data, token) => {

	let requestObject = {
		serviceType: data
	}

	return dispatch => {
		dispatch(startLoading());
		RestClient.get("users/getProductUnits", requestObject, token).then((result) => {
			console.log(result, '****** getProductUnits	 ****')
			if (result.statusCode == 200) {
				dispatch(stopLoading());
				// dispatch(ToastActionsCreators.displayInfo(result.message));
				dispatch(PRODUCTUNITS(result));

			}
			else {
				dispatch(stopLoading());
				// dispatch(ToastActionsCreators.displayInfo(result.message));
			}
		}).catch(error => {
			
			console.log("error=> ", error)
			dispatch(stopLoading());
		});
	}
};



/**
* choose User Type API.
*/
export const setConfiguration = (data) => {
	console.log(data)
	let requestObject = ''
	if (data.role == "Customer") {
		requestObject = {
			role: data.role,
			preferredLanguage: data.language,
			firstName: data.firstName,
			lastName: data.lastName,
			email: data.emailId,
			customerAddress: data.address,
			zipCode: data.zipCode,
			profileImg: data.imageUrl,
		}
	} else {
		requestObject = {
			role: data.role,
			preferredLanguage: data.language,
			firstName: data.firstName,
			lastName: data.lastName,
			email: data.emailId,
			businessAddress: data.businessAddress,
			businessName: data.businessName,
			zipCode: data.zipCode,
			profileImg: data.imageUrl,
		}
	}

	return dispatch => {
		dispatch(startLoading());
		RestClient.post("users/setConfiguration", requestObject, data.user.userDetails.data.token).then((result) => {
			console.log(result, '****** setConfiguration ****')
			if (result.statusCode === 200) {
				dispatch(stopLoading());
				// dispatch(ToastActionsCreators.displayInfo(result.message));
				if (result.data.role == "Service Provider") {
					dispatch(SERVICESANDSCHEDULING(result));
				}
				else if (result.data.role == "Customer") {
					dispatch(SCHEDULEANDPRODUCTS(result));
				}
			}
			else {
				dispatch(stopLoading());
				// dispatch(ToastActionsCreators.displayInfo(result.message));
			}
		}).catch(error => {
			console.log("error=> ", error)
			dispatch(stopLoading());
		});
	}
};



export const addProduct = (data) => {

	let requestObject = {
		serviceTypeId: data.serviceTypeId,
		productName: data.name,
		productDescription: data.description,
		price: data.price,
		unit: data.unit,
		productImage: data.imageUrl,
		serviceType: data.serviceType
	}

	return dispatch => {
		dispatch(startLoading());
		RestClient.post("users/addProducts", requestObject, data.user.userDetails.data.token).then((result) => {
			console.log(result, '****** addProduct ****')
			if (result.statusCode === 200) {
				dispatch(stopLoading());
				dispatch(ToastActionsCreators.displayInfo("Product created successfully"));

			}
			else if(result.message == "Same Product with this service ID already exist.") {
				dispatch(stopLoading());
				dispatch(ToastActionsCreators.displayInfo("You have already added this product"));
			
			} 
			// else {
			// 	dispatch(ToastActionsCreators.displayInfo("Product not added"));
			
			// }
		}).catch(error => {
			console.log("error=> ", error)
			dispatch(stopLoading());
		});
	}
};

export const addProductNavigation = (data) => {

	let requestObject = {
		serviceTypeId: data.serviceTypeId,
		productName: data.name,
		productDescription: data.description,
		price: data.price,
		unit: data.unit,
		productImage: data.imageUrl,
		serviceType: data.serviceType
	}

	return dispatch => {
		dispatch(startLoading());
		RestClient.post("users/addProducts", requestObject, data.user.userDetails.data.token).then((result) => {
			console.log(result, '****** addProductNavigation ****')
			if (result.statusCode === 200) {
				dispatch(stopLoading());
				// dispatch(ToastActionsCreators.displayInfo(result.message));
				dispatch(SUCCESS(true))
			}
			else if(result.message == "Same Product with this service ID already exist.") {
				dispatch(stopLoading());
				dispatch(ToastActionsCreators.displayInfo("You have already added this product"));
				// dispatch(SUCCESS(false))
			} else {
				dispatch(ToastActionsCreators.displayInfo("Product not added"));
				// dispatch(SUCCESS(false))
			}

		}).catch(error => {
			console.log("error=> ", error)
			dispatch(stopLoading());
		});
	}
};


export const getReferralData = (data, token, role) => {
	console.log(data, token, role)

	let requestObject = {
		referralCode: data
	}

	return dispatch => {
		dispatch(startLoading());
		RestClient.post("users/getReferralData", requestObject, token).then((result) => {
			console.log(result, '****** getReferralData ****')
			if (result.statusCode === 200) {
				dispatch(stopLoading());
				// dispatch(ToastActionsCreators.displayInfo(result.message));
				dispatch(REFERRALDATA(result));
				if (role == "Customer") {
					dispatch(REFERRALDATACUSTOMER(result));
				}
			}
			else {
				dispatch(stopLoading());
				dispatch(ToastActionsCreators.displayInfo("Please enter valid referral code"));
			}
		}).catch(error => {
			console.log("error=> ", error)
			dispatch(stopLoading());
		});
	}
};



export const getUserServices = (data, token) => {

	let requestObject = {
		serviceProviderId: data
	}

	return dispatch => {
		// dispatch(startLoading());
		RestClient.get("users/getUserServices", requestObject, token).then((result) => {
			console.log(result, '****** getUserServices ****')
			if (result.statusCode === 200) {
				dispatch(stopLoading());
				// dispatch(ToastActionsCreators.displayInfo(result.message));
				dispatch(USERSERVICES(result));

			}
			else {
				dispatch(stopLoading());
				// dispatch(ToastActionsCreators.displayInfo(result.message));
			}
		}).catch(error => {
			console.log("error=> ", error)
			dispatch(stopLoading());
		});
	}
};


export const getUserServices1 = (data, token) => {

	let requestObject = {
		serviceProviderId: data
	}

	return dispatch => {
		// dispatch(startLoading());
		RestClient.get("users/getUserServices", requestObject, token).then((result) => {
			console.log(result, '****** getUserServices1 ****')
			if (result.statusCode === 200) {
				dispatch(stopLoading());
				// dispatch(ToastActionsCreators.displayInfo(result.message));
				dispatch(USERSERVICES1(result));

			}
			else {
				dispatch(stopLoading());
				// dispatch(ToastActionsCreators.displayInfo(result.message));
			}
		}).catch(error => {
			console.log("error=> ", error)
			dispatch(stopLoading());
		});
	}
};



export const getProducts = (data, token) => {

	let requestObject = {
		serviceTypeId: data
	}

	return dispatch => {
		dispatch(startLoading());
		RestClient.post("users/getProducts", requestObject, token).then((result) => {
			console.log(result, '****** getProducts ****')
			if (result.statusCode === 200) {
				dispatch(stopLoading());
				// dispatch(ToastActionsCreators.displayInfo(result.message));
				dispatch(PRODUCTDATA(result));

			}
			else {
				dispatch(stopLoading());
				// dispatch(ToastActionsCreators.displayInfo(result.message));
			}
		}).catch(error => {
			console.log("error=> ", error)
			dispatch(stopLoading());
		});
	}
};



export const getProducts1 = (data, token) => {

	let requestObject = {
		serviceTypeId: data
	}

	return dispatch => {
		dispatch(startLoading());
		RestClient.post("users/getProducts", requestObject, token).then((result) => {
			console.log(result, '****** getProducts1 ****')
			if (result.statusCode === 200) {
				dispatch(stopLoading());
				// dispatch(ToastActionsCreators.displayInfo(result.message));
				dispatch(PRODUCTDATA1(result));

			}
			else {
				dispatch(stopLoading());
				// dispatch(ToastActionsCreators.displayInfo(result.message));
			}
		}).catch(error => {
			console.log("error=> ", error)
			dispatch(stopLoading());
		});
	}
};



export const setScheduling = (data) => {
	console.log(data)
	let requestObject = {
		firstName: data.name,
		phoneNumber: data.number,
		serviceTypeId: data.serviceTypeId,
		productId: data.productId,
		startDate: data.from,
		endDate: data.to,
		occurrence: data.occurence,
		quantity: data.quantity

	}

	return dispatch => {
		dispatch(startLoading());
		RestClient.post("users/setScheduling", requestObject, data.user.userDetails.data.token).then((result) => {
			console.log(result, '****** setScheduling ****')
			if (result.statusCode === 200) {
				dispatch(stopLoading());
				dispatch(ToastActionsCreators.displayInfo(result.message));
				dispatch(PROFILEDATA(result));

			}
			else if (result.statusCode === 400) {
				dispatch(stopLoading());
				dispatch(ToastActionsCreators.displayInfo(result.message));
			}
			else if(result.statusCode === 403) {
				dispatch(stopLoading());
				dispatch(ToastActionsCreators.displayInfo("Schedule not created"));
			}
		}).catch(error => {
			console.log("error=> ", error)
			dispatch(stopLoading());
		});
	}
};



export const setSchedulingNavigation = (data) => {
	console.log(data)
	let requestObject = {
		firstName: data.name,
		phoneNumber: data.number,
		serviceTypeId: data.serviceTypeId,
		productId: data.productId,
		startDate: data.from,
		endDate: data.to,
		occurrence: data.occurence,
		quantity: data.quantity

	}

	return dispatch => {
		dispatch(startLoading());
		RestClient.post("users/setScheduling", requestObject, data.user.userDetails.data.token).then((result) => {
			console.log(result, '****** setScheduling ****')
			console.log(JSON.stringify(result))
			if (result.statusCode === 200) {
				dispatch(stopLoading());
				// dispatch(ToastActionsCreators.displayInfo(result.message));
				dispatch(DASHBOARD(result));

			}
			else {
				dispatch(stopLoading());
				// dispatch(ToastActionsCreators.displayInfo(result.message));
			}
		}).catch(error => {
			console.log("error=> ", error)
			dispatch(stopLoading());
		});
	}
};



export const getCustomerList = (token) => {

	return dispatch => {
		dispatch(startLoading());
		RestClient.get("users/getCustomerList", {}, token).then((result) => {
			console.log(result, '****** getCustomerList ****')
			if (result.statusCode === 200) {
				dispatch(stopLoading());
				// dispatch(ToastActionsCreators.displayInfo(result.message));
				dispatch(CUSTOMERLIST(result));
			}
			else {
				dispatch(stopLoading());
				// dispatch(ToastActionsCreators.displayInfo(result.message));
			}
		}).catch(error => {
			console.log("error=> ", error)
			dispatch(stopLoading());
		});
	}
};




export const getCustomerData = (data, token) => {


	let requestObject = {
		customerId: data
	}

	return dispatch => {
		dispatch(startLoading());
		RestClient.get("users/getCustomerData", requestObject, token).then((result) => {
			console.log(result, '****** getCustomerData ****')
			if (result.statusCode === 200) {
				dispatch(stopLoading());
				// dispatch(ToastActionsCreators.displayInfo(result.message));
				dispatch(CUSTOMERDATA(result))
			}
			else {
				dispatch(stopLoading());
				// dispatch(ToastActionsCreators.displayInfo(result.message));
			}
		}).catch(error => {
			console.log("error=> ", error)
			dispatch(stopLoading());
		});
	}
};



export const getScheduledProducts = (serviceTypeId, Id, token) => {


	let requestObject = {
		Id: Id,
		serviceTypeId: serviceTypeId
	}

	return dispatch => {
		dispatch(startLoading());
		RestClient.get("users/getScheduledProducts", requestObject, token).then((result) => {
			console.log(result, '****** getScheduledProducts ****')
			if (result.statusCode === 200) {
				dispatch(stopLoading());
				// dispatch(ToastActionsCreators.displayInfo(result.message));
				dispatch(PRODUCTDATA(result));
			}
			else {
				dispatch(stopLoading());
				// dispatch(ToastActionsCreators.displayInfo(result.message));
			}
		}).catch(error => {
			console.log("error=> ", error)
			dispatch(stopLoading());
		});
	}
};




export const updateScheduling = (data) => {
	console.log(data)
	let requestObject = {
		customerPhoneNumber: data.number,
		customerId: data.customerId,
		customerName: data.name,
		serviceTypeId: data.serviceTypeId,
		productId: data.productId,
		startDate: data.from,
		endDate: data.to,
		occurrence: data.occurence,
		quantity: data.quantity,
		// productName : data.product,
		// serviceType : data.service,
		startOffDate: data.fromDayOff,
		days: data.day,
		scheduleID: data.scheduleID




	}

	return dispatch => {
		dispatch(startLoading());
		RestClient.post("users/updateCustomerData", requestObject, data.user.userDetails.data.token).then((result) => {
			console.log(result, '****** updateCustomerData ****')
			if (result.statusCode === 200) {
				dispatch(stopLoading());
				dispatch(ToastActionsCreators.displayInfo("Data updated"));
				dispatch(PRODUCTDATA(result));
			}
			else if (result.statusCode === 400) {
				dispatch(stopLoading());
				if(result.message == "Products with this info already added.")
				{dispatch(ToastActionsCreators.displayInfo(result.message));}

			}
			else {
				dispatch(stopLoading());
				// dispatch(ToastActionsCreators.displayInfo(result.message));
			}
		}).catch(error => {
			console.log("error=> ", error)
			dispatch(stopLoading());
		});
	}
};


export const updateProducts = (data) => {
	console.log(data)
	let requestObject = {
		productId: data.productId,
		serviceTypeId: data.serviceTypeId,
		productName: data.product,
		productDescription: data.productDescription,
		price: data.price,
		unit: data.unit,
		productImage: data.imageUrl

	}

	return dispatch => {
		dispatch(startLoading());
		RestClient.put("users/updateProducts", requestObject, data.user.userDetails.data.token).then((result) => {
			console.log(result, '****** updateProducts ****')
			if (result.statusCode === 200) {
				dispatch(stopLoading());
				dispatch(ToastActionsCreators.displayInfo("Products data updated"));


			}
			else {
				dispatch(stopLoading());
				// dispatch(ToastActionsCreators.displayInfo(result.message));
			}
		}).catch(error => {
			console.log("error=> ", error)
			dispatch(stopLoading());
		});
	}
};


export const getOffDateEntries = (date, token) => {


	let requestObject = {
		startDate: date,
		endDate: date
	}

	return dispatch => {
		dispatch(startLoading());
		RestClient.post("users/getOffDateEntries", requestObject, token).then((result) => {
			console.log(result, '****** getOffDateEntries ****')
			if (result.statusCode === 200) {
				dispatch(stopLoading());
				// dispatch(ToastActionsCreators.displayInfo(result.message));
				dispatch(OFFDATEENTRY(result));
			}
			else {
				dispatch(stopLoading());
				// dispatch(ToastActionsCreators.displayInfo(result.message));
			}
		}).catch(error => {
			console.log("error=> ", error)
			dispatch(stopLoading());
		});
	}
};



export const getEachSchedule = (date, token) => {

	console.log(date)
	let requestObject = {
		startDate: date,
		endDate: date
	}

	return dispatch => {
		dispatch(startLoading());
		RestClient.post("users/getEachSchedules", requestObject, token).then((result) => {
			console.log(result, '****** getEachSchedules ****')
			if (result.statusCode === 200) {
				dispatch(stopLoading());
				// dispatch(ToastActionsCreators.displayInfo(result.message));
				dispatch(SCHEDULESTATUS(result));
			}
			else {
				dispatch(stopLoading());
				// dispatch(ToastActionsCreators.displayInfo(result.message));
			}
		}).catch(error => {
			console.log("error=> ", error)
			dispatch(stopLoading());
		});
	}
};



export const getEarning = (startDate, endDate, token) => {


	let requestObject = {
		startDate: startDate,
		endDate: endDate
	}

	return dispatch => {
		// dispatch(startLoading());
		RestClient.get("dashboard/fullEarning", requestObject, token).then((result) => {
			console.log(result, '****** getEarning ****')
			if (result.statusCode === 200) {
				// dispatch(stopLoading());
				// dispatch(ToastActionsCreators.displayInfo(result.message));
				dispatch(GETEARNING(result));
			}
			else {
				// dispatch(stopLoading());
				// dispatch(ToastActionsCreators.displayInfo(result.message));
			}
		}).catch(error => {
			console.log("error=> ", error)
			dispatch(stopLoading());
		});
	}
};



export const getCount = (date, token) => {
	let requestObject = {
		startDate: date,
		endDate: date
	}
	return dispatch => {
		// dispatch(startLoading());
		RestClient.get("dashboard/getDailyCount", requestObject, token).then((result) => {
			console.log(result, '****** getCount ****')
			if (result.statusCode === 200) {
				// dispatch(stopLoading());
				// dispatch(ToastActionsCreators.displayInfo(result.message));
				dispatch(GETCOUNT(result));
			}

			else {
				// dispatch(stopLoading());
				// dispatch(ToastActionsCreators.displayInfo(result.message));
			}
		}).catch(error => {
			console.log("error=> ", error)
			dispatch(stopLoading());
		});
	}
};



export const getServiceSchedule = (date, serviceTypeId, token) => {

	let requestObject = {
		serviceTypeId: serviceTypeId,
		startDate: date,
		endDate: date

	}

	return dispatch => {
		// dispatch(startLoading());
		RestClient.get("dashboard/getServiceSchedule", requestObject, token).then((result) => {
			console.log(result, '****** getServiceSchedule ****')
			if (result.statusCode === 200) {
				// dispatch(stopLoading());
				// dispatch(ToastActionsCreators.displayInfo(result.message));
				dispatch(SCHEDULESTATUS(result));
			}
			else if (result.statusCode == 400) {
				dispatch(SCHEDULESTATUS(null));
			}
			else {
				// dispatch(stopLoading());
				// dispatch(ToastActionsCreators.displayInfo(result.message));
			}
		}).catch(error => {
			console.log("error=> ", error)
			dispatch(stopLoading());
		});
	}
};


export const logOut = () => {
	return dispatch => {
		dispatch(LOGOUT());

	}
};


export const setDeviceToken = (token) => {
	console.log(token, "DEVICETOKEN")
	return dispatch => {
		console.log('inside return dispatch token ******** ', token)
		dispatch(SETDEVICETOKEN(token));
	}
};

export const getUserProfile = (token) => {


	return dispatch => {
		dispatch(startLoading());
		RestClient.get("users/getUserProfile", {}, token).then((result) => {
			console.log(result, '****** getUserProfile ****')
			if (result.statusCode === 200) {
				dispatch(stopLoading());
				// dispatch(ToastActionsCreators.displayInfo(result.message));
				dispatch(PROFILEDATA(result));
			}
			else {
				dispatch(stopLoading());
				// dispatch(ToastActionsCreators.displayInfo(result.message));
			}
		}).catch(error => {
			console.log("error=> ", error)
			dispatch(stopLoading());
		});
	}
};


export const updateProfile = (data) => {
	console.log(data)

	let requestObject = ''
	if (data.role == "Customer") {
		requestObject = {
			role: data.role,
			preferredLanguage: data.language,
			firstName: data.firstName,
			lastName: data.lastName,
			email: data.emailId,
			customerAddress: data.address,
			zipCode: data.zipCode,
			profileImg: data.imageUrl,
		}
	} else {
		requestObject = {
			role: data.role,
			preferredLanguage: data.language,
			firstName: data.firstName,
			lastName: data.lastName,
			email: data.emailId,
			businessAddress: data.businessAddress,
			businessName: data.businessName,
			zipCode: data.zipCode,
			profileImg: data.imageUrl,
		}
	}

	return dispatch => {
		dispatch(startLoading());
		RestClient.put("users/updateProfile", requestObject, data.user.userDetails.data.token).then((result) => {
			console.log(result, '****** updateProfile ****')
			if (result.statusCode === 200) {
				dispatch(stopLoading());
				dispatch(ToastActionsCreators.displayInfo(result.message));
			}
			else {
				dispatch(stopLoading());
				// dispatch(ToastActionsCreators.displayInfo(result.message));
			}
		}).catch(error => {
			console.log("error=> ", error)
			dispatch(stopLoading());
		});
	}
};


export const updateLanguage = (language, token) => {

	let requestObject = {
		preferredLanguage: language
	}

	return dispatch => {
		dispatch(startLoading());
		RestClient.put("users/updateLanguage", requestObject, token).then((result) => {
			console.log(result, '****** updateLanguage ****')
			if (result.statusCode === 200) {
				dispatch(stopLoading());
				dispatch(ToastActionsCreators.displayInfo(result.message));
			}
			else {
				dispatch(stopLoading());
				// dispatch(ToastActionsCreators.displayInfo(result.message));
			}
		}).catch(error => {
			console.log("error=> ", error)
			dispatch(stopLoading());
		});
	}
};




//*****************************CUSTOMER APIS +++++++++++++++++++++++++ */



export const setCustomerSchedule = (data) => {
	console.log(data)
	let requestObject = ""
	if (data.productId == "") {
		requestObject = {
			name: data.name,
			phoneNumber: data.number,
			serviceTypeId: data.serviceTypeId,
			productName: data.productName,
			productDescription: data.description,
			startDate: data.from,
			endDate: data.to,
			occurrence: data.occurence,
			quantity: data.quantity,
			price: data.price,
			unit: data.unit,
			productImage: data.imageUrl

		}
	}
	else {
		requestObject = {
			name: data.name,
			phoneNumber: data.number,
			serviceTypeId: data.serviceTypeId,
			productName: data.productName,
			productId: data.productId,
			startDate: data.from,
			endDate: data.to,
			occurrence: data.occurence,
			quantity: data.quantity,
			price: data.price,
			unit: data.unit,
			productImage: data.imageUrl

		}
	}



	return dispatch => {
		dispatch(startLoading());
		RestClient.post("users/setCustomerSchedule", requestObject, data.user.userDetails.data.token).then((result) => {
			console.log(result, '****** setCustomerSchedule ****')
			console.log(JSON.stringify(result))
			if (result.statusCode === 200) {
				dispatch(stopLoading());
				dispatch(ToastActionsCreators.displayInfo(result.message));
				dispatch(PROFILEDATA(result));

			}
			if (result.statusCode === 400) {
				dispatch(stopLoading());
			if(result.message == "Products with this info already added."||"Schedule with same Info already added.")
				{dispatch(ToastActionsCreators.displayInfo(result.message));}

			}
			else if(result.statusCode === 403){
				dispatch(stopLoading());
				if(result.message == "Products with this info already added.")
				{dispatch(ToastActionsCreators.displayInfo(result.message));}
				else{
					dispatch(ToastActionsCreators.displayInfo("Schedule not created"));
				}

				// dispatch(ToastActionsCreators.displayInfo(result.message));
			}
		}).catch(error => {
			console.log("error=> ", error)
			dispatch(stopLoading());
		});
	}
};


export const getServiceProviderList = (token) => {

	return dispatch => {
		dispatch(startLoading());
		RestClient.get("users/getServiceProviderList", {}, token).then((result) => {
			console.log(result, '****** getServiceProviderList ****')
			if (result.statusCode === 200) {
				dispatch(stopLoading());
				// dispatch(ToastActionsCreators.displayInfo(result.message));
				dispatch(SERVICEPROVIDERLIST(result));
			}
			else {
				dispatch(stopLoading());
				// dispatch(ToastActionsCreators.displayInfo(result.message));
			}
		}).catch(error => {
			console.log("error=> ", error)
			dispatch(stopLoading());
		});
	}
};


export const getServiceProviderData = (data, token) => {


	let requestObject = {
		serviceProviderId: data
	}

	return dispatch => {
		dispatch(startLoading());
		RestClient.get("users/getServiceProviderData", requestObject, token).then((result) => {
			console.log(result, '****** getServiceProviderData ****')
			if (result.statusCode === 200) {
				dispatch(stopLoading());
				// dispatch(ToastActionsCreators.displayInfo(result.message));
				dispatch(SERVICEPROVIDERDATA(result))
			}
			else {
				dispatch(stopLoading());
				// dispatch(ToastActionsCreators.displayInfo(result.message));
			}
		}).catch(error => {
			console.log("error=> ", error)
			dispatch(stopLoading());
		});
	}
};


export const updateCustomerSchedule = (data) => {
	console.log(data)
	let requestObject = {
		serviceProviderphoneNumber: data.number,
		serviceProviderId: data.serviceProviderId,
		scheduleID: data.scheduleID,
		serviceProviderName: data.name,
		serviceTypeId: data.serviceTypeId,
		productId: data.productId,
		startDate: data.from,
		endDate: data.to,
		occurrence: data.occurence,
		quantity: data.quantity,
		role: data.user.userDetails.data.role,
		startOffDate: data.fromDayOff,
		days: data.day
	}

	return dispatch => {
		dispatch(startLoading());
		RestClient.post("users/updateCustomerSchedule", requestObject, data.user.userDetails.data.token).then((result) => {
			console.log(result, '****** updateCustomerSchedule ****')
			if (result.statusCode === 200) {
				dispatch(stopLoading());
				dispatch(ToastActionsCreators.displayInfo("Data updated"));

			}
			else {
				dispatch(stopLoading());
				// dispatch(ToastActionsCreators.displayInfo(result.message));
			}
		}).catch(error => {
			console.log("error=> ", error)
			dispatch(stopLoading());
		});
	}
};



export const getProductData = (serviceTypeId, serviceProviderId, token) => {

	let requestObject = {
		serviceTypeId: serviceTypeId,
		serviceProviderId: serviceProviderId
	}

	return dispatch => {
		dispatch(startLoading());
		RestClient.get("users/getProductData", requestObject, token).then((result) => {
			console.log(result, '****** getProductData ****')
			if (result.statusCode === 200) {
				dispatch(stopLoading());
				// dispatch(ToastActionsCreators.displayInfo(result.message));
				dispatch(PRODUCTDATA(result));

			}
			else {
				dispatch(stopLoading());
				// dispatch(ToastActionsCreators.displayInfo(result.message));
			}
		}).catch(error => {
			console.log("error=> ", error)
			dispatch(stopLoading());
		});
	}
};


export const setNotificationStatus = (deviceToken, type, token) => {

	let requestObject = {
		deviceToken: deviceToken,
		type: type
	}

	return dispatch => {
		dispatch(startLoading());
		RestClient.post("users/setNotificationStatus", requestObject, token).then((result) => {
			console.log(result, '****** setNotificationStatus ****')
			if (result.statusCode === 200) {
				dispatch(stopLoading());
				// dispatch(ToastActionsCreators.displayInfo(result.message));

			}
			else {
				dispatch(stopLoading());
				// dispatch(ToastActionsCreators.displayInfo(result.message));
			}
		}).catch(error => {
			console.log("error=> ", error)
			dispatch(stopLoading());
		});
	}
};


export const updateNotificationSettings = (data, token) => {
	console.log(data)
	let requestObject = {
		notificationData: data
	}

	return dispatch => {
		dispatch(startLoading());
		RestClient.put("users/updateNotificationSettings", requestObject, token).then((result) => {
			console.log(result, '****** updateNotificationSettings ****')
			if (result.statusCode === 200) {
				dispatch(stopLoading());
				// dispatch(ToastActionsCreators.displayInfo(result.message));
			}
			else {
				dispatch(stopLoading());
				// dispatch(ToastActionsCreators.displayInfo(result.message));
			}
		}).catch(error => {
			console.log("error=> ", error)
			dispatch(stopLoading());
		});
	}
};


export const getReports = (startDate, endDate, token) => {
	let requestObject = {
		startDate: startDate,
		endDate: endDate
	}
	debugger;
	return dispatch => {
		dispatch(startLoading());
		RestClient.get("dashboard/getReportsData", requestObject, token).then((result) => {
			console.log(result, '****** getReportsData ****')
			if (result.statusCode == 200) {
			
				dispatch(GETREPORTS(result));
				dispatch(stopLoading());
			}
			else {
				dispatch(stopLoading());
			}
		}).catch(error => {
			console.log("error=> ", error)
			dispatch(stopLoading());
		});
	}
};


export const getNotificationSettings = (token) => {

	    return dispatch => {
	        dispatch(startLoading());
	        RestClient.get("users/getNotificationSettings", {}, token).then((result) => {
	            console.log(result, '****** getNotificationSettings  ****')
	            if (result.statusCode === 200) {
	                dispatch(stopLoading());
	                dispatch(NOTIFICATIONSETTINGS(result));
	
	            }
	            else {
	                dispatch(stopLoading());
	            
	            }
	        }).catch(error => {
	            console.log("error=> ", error)
	            dispatch(stopLoading());
	        });
	    }
	};


export const phoneNumberCheck = (data, token) => {
	console.log(data)

	let requestObject = {
		phoneNumber: data
	}

	return dispatch => {
		dispatch(startLoading());
		RestClient.post("users/checkDetails", requestObject, token).then((result) => {
			console.log(result, "****** checkDetails ********")
			if (result.statusCode === 200) {
				dispatch(stopLoading());
				dispatch(NUMBEREXISTENCE(result))
			}
			else {
				dispatch(stopLoading());
				dispatch(ToastActionsCreators.displayInfo(result.message));
			}
		}).catch(error => {
			console.log("error=> ", error)
			dispatch(stopLoading());
		});
	}
};
	

export const getNotificationData = (token) => {

	    return dispatch => {
	        dispatch(startLoading());
	        RestClient.get("users/getNotificationData", {}, token).then((result) => {
	            console.log(result, '****** getNotificationData ****')
	            if (result.statusCode === 200) {
	                dispatch(stopLoading());
	                dispatch(NOTIFICATIONDATA(result));
	
	            }
	            else {
	                dispatch(stopLoading());
	            
	            }
	        }).catch(error => {
	            console.log("error=> ", error)
	            dispatch(stopLoading());
	        });
	    }
	};


export const getNotificationCount = (token) => {

	    return dispatch => {
	        dispatch(startLoading());
	        RestClient.get("users/getNotificationCount", {}, token).then((result) => {
	            console.log(result, '****** getNotificationCount ****')
	            if (result.statusCode === 200) {
	                dispatch(stopLoading());
	                dispatch(NOTIFICATIONCOUNT(result));
	            }
	            else {
	                dispatch(stopLoading());
	            }
	        }).catch(error => {
	            console.log("error=> ", error)
	            dispatch(stopLoading());
	        });
	    }
	};



export const updateNotificationStatus = (notificationId, status, token) => {

	let requestObject = {
		notificationId: notificationId,
		status: status
	}

	return dispatch => {
		dispatch(startLoading());
		RestClient.put("users/updateNotificationStatus", requestObject, token).then((result) => {
			console.log(result, '****** updateNotificationStatus ****')
			if (result.statusCode === 200) {
				dispatch(stopLoading());
				// dispatch(ToastActionsCreators.displayInfo(result.message));
			}
			else {
				dispatch(stopLoading());
				// dispatch(ToastActionsCreators.displayInfo(result.message));
			}
		}).catch(error => {
			console.log("error=> ", error)
			dispatch(stopLoading());
		});
	}
};



export const deleteUser = (userId, role, token) => {
	

	let requestObject = {
		userId: userId,
		role: role
	}

	return dispatch => {
		dispatch(startLoading());
		RestClient.post("users/deleteSchedules", requestObject, token).then((result) => {
			console.log(result, "****** deleteSchedules ********")
			if (result.statusCode === 200) {
				dispatch(stopLoading());
			}
			else {
				dispatch(stopLoading());
				dispatch(ToastActionsCreators.displayInfo(result.message));
			}
		}).catch(error => {
			console.log("error=> ", error)
			dispatch(stopLoading());
		});
	}
};




/**
* Initial state
*/
const initialState = {
	userDetails: null,
	deviceToken: "test",
	referralData: null,
	appServices: null,
	userServices: null,
	productData: null,
	customerList: null,
	customerData: null,
	offDateEntry: null,
	scheduleStatus: null,
	getEarning: null,
	getCount: null,
	getReports: null,
	productUnits: null,
	countryCodes: null,
	countryCode: null,
	notificationSettings: null,
	productData1: null,
	numberExistence: null,
	userServices1: null,
	success: null,
	notificationData: null,
	notificationCount: null,

	//************* CUSTOMER ********* */

	serviceProviderList: null,
	serviceProviderData: null,

};

/**
* Reducer
*/
export default function reducer(state = initialState, action) {

	switch (action.type) {

		case REGISTER_NEW_USER:
			return { ...state, userDetails: action.data };

		case USER_TYPE:
			return { ...state, userDetails: action.data };

		case RESET_PASSWORD:
			return { ...state, userDetails: action.data };

		case GO_TO_LOGIN:
			return { ...state, userDetails: action.data	,success: null };

		case APP_SERVICES:
			return { ...state, appServices: action.data , referralData: null};

		case PRODUCT_UNITS:
			return { ...state, productUnits: action.data };

		case SERVICES_AND_SCHEDULING:
			return { ...state, userDetails: action.data, referralData: null,success: null };

		case DASH_BOARD:
			return { ...state, userDetails: action.data ,success: null};

		case REFERRAL_DATA:
			return { ...state, referralData: action.data, userServices: null ,success: null};

		case USER_SERVICES:
			return { ...state, userServices: action.data, numberExistence: null  ,success: null};
			
		case USER_SERVICES1:
			return { ...state, userServices1: action.data, numberExistence: null  ,success: null};

		case PRODUCT_DATA:
			return { ...state, productData: action.data,success: null };

		case CUSTOMER_LIST:
			return { ...state, customerList: action.data, productData: null,success: null };

		case CUSTOMER_DATA:
			return { ...state, customerData: action.data, productData: null ,success: null};

		case OFF_DATE_ENTRY:
			return { ...state, offDateEntry: action.data,success: null };

		case SCHEDULE_STATUS:
			return { ...state, scheduleStatus: action.data ,success: null};

		case GET_EARNING:
			return { ...state, getEarning: action.data ,success: null};

		case GET_COUNT:
			return { ...state, getCount: action.data ,success: null};

		case GET_REPORTS:
			return { ...state, getReports: action.data ,success: null};

		case PROFILE_DATA:
			return { ...state, userDetails: action.data, referralData: null ,success: null};

		case SERVICE_PROVIDER_LIST:
			return { ...state, serviceProviderList: action.data, productData: null, numberExistence: null ,success: null};

		case SERVICE_PROVIDER_DATA:
			return { ...state, serviceProviderData: action.data, productData: null ,success: null};

		case REFERRAL_DATA_CUSTOMER:
			return { ...state, referralData: action.data, userServices: null ,success: null};

		case SCHEDULE_AND_PRODUCTS:
			return { ...state, userDetails: action.data, numberExistence: null ,success: null};

		case CUSTOMER_DASH_BOARD:
			return { ...state, userDetails: action.data ,success: null};

		case DEVICE_TOKEN:
			return { ...state, deviceToken: action.data }

		case COUNTRY_CODES:
			return { ...state, countryCodes: action.data }

		case COUNTRY_CODE:
			return { ...state, countryCode: action.data }

		case NOTIFICATION_SETTINGS:
			return { ...state, notificationSettings: action.data }

		case PRODUCT_DATA1:
			return { ...state, productData1: action.data };
		
		case SUCCESS_DONE:
			return { ...state, success: action.data };

		case NUMBER_EXISTENCE:
			return { ...state, numberExistence: action.data };

		case NOTIFICATION_DATA:
			return { ...state, notificationData: action.data };

		case NOTIFICATION_COUNT:
			console.log('notification count ********** ',action.data)
			return { ...state, notificationCount: action.data };	

		case LOG_OUT:
			return { ...initialState, deviceToken: state.deviceToken }
		default:
			return state;
	}
}
